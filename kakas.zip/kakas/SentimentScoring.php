<?php

	class SentimentScoring {
		
		private $listPositive;

		private $listNegative;

		function __construct(){

			$dataListPositive = file("kakas/OpinionWord/positive.txt");
			
			$dataListNegative = file("kakas/OpinionWord/negative.txt");
			
			foreach ($dataListPositive as $word) {

				$this->listPositive[] = rtrim($word);

			}

			foreach ($dataListNegative as $word) {

				$this->listNegative[] = rtrim($word);

			}
		}

		function getListPositive(){
			return $this->listPositive;
		}

		function getListNegative(){
			return $this->listNegative;
		}
	}	
?>