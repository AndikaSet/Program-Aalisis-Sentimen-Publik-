<?php 
	require_once './vendor/autoload.php';
	require_once "FormalizerRule.php";

	class IndonesianSentenceFormalizer{
		private $listUnformal;

		function __construct(){

			$dataListUnformal = file("kakas/formalizer/formalizationDict.txt");
			
			foreach ($dataListUnformal as $string) {
				$word = preg_split("/[\t]/", $string);
				$this->listUnformal[$word[0]] = $word[1];
			}
		}

		function normalizeSentenceWithoutsTokenization($listToken){
			$normSet = array();
			foreach ($listToken as $value) {
				$normSet[] = $this->formalizeWord($value);
			}

			return implode(" ", $normSet);
		}

		function normalizeSentence($sentence){
			$sentence = strtolower($sentence);
			$sentence = $this->replaceEmoji($sentence);

			$tokenizerFactory  = new \Sastrawi\Tokenizer\TokenizerFactory();
			$tokenizer = $tokenizerFactory->createDefaultTokenizer();
			$listToken = $tokenizer->tokenize($sentence);

			$listToken = array_map(function($value){
				return trim($value);
			}, $listToken);

			$listToken = $this->removePunctuationMark($listToken);

			$formalSentence = $this->normalizeSentenceWithoutsTokenization($listToken);

			return $formalSentence;
		}

		function formalizeWord($word){
			$ruleName = "";
			$ruleCondition = "";
			$rule = "";
			$outword = $word;

			if(array_key_exists(rtrim($word), $this->listUnformal)){
				$outword = rtrim($this->listUnformal[$word]);
			}
			else if ($this->isMention($word)) {
				$outword = "";
			}
			else if ($this->isHashtag($word)) {
				$outword = "";
			}
			else if ($this->isRetweet($word)){
				$outword = "";
			}
			else if ($this->isLink($word)) {
				$outword = "";
			}
			else if ($this->isNumber($word)) {
				$outword = "";
			}
			else {
				$formalizerRule = new FormalizerRule($word);

				$word = $formalizerRule->getFormalizedWord();

				$outword = $word;

			}

			return $outword;
		}
		function isLink($token){
			return preg_match("/((http|https)?:\/\/)?(www.)?[\w\-\.~]+\.[a-z]{2,6}(\/[\w\-\.~]*)*/", $token);
		}
		
		function isMention($token){
			return preg_match("/@\w+\W*/", $token);
		}

		function isRetweet($token){
			return preg_match("/rt/", $token);
		}

		function isHashtag($token){
			return preg_match("/#([^\s]+)/", $token);
		}
		
		function isTime($token){
			if (preg_match("/([12])?\d([\:\.])\d{2}(\2\d{2})?([aApP][mM])?/", $token)) {
				return true;
			}
			if (preg_match("/\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4}/", $token)) {
				return true;
			}
			return preg_match("/\d{2,4}[\/\-\.]\d{1,2}[\/\-\.]\d{1,2}/", $token);
		}

		function isNumber($token){
			return preg_match("/\b(?<!-)\d+(?!-)\b/", $token);
		}

		function removePunctuationMark($listWord){
	    	$punctuationChars = array(
		        ',', '.', ';', ':', '?', '!', '"', '(', ')', '\'',
		        '[', ']', '+', '=', '*', '&', '^', '%', '$', '~', '`', '{', '}', '\\', '|', '>', '<',
		    );

		    foreach ($listWord as $key => $value) {
		    	if(in_array($value, $punctuationChars))
				{
					$key = array_search($value, $listWord);
					unset($listWord[$key]);
				}
		    }

		    return $listWord;
		}

		function replaceEmoji($sentence){
			
			$emoticons = array(
			    ':-)' => 'senang',
			    ':)' => 'senang',
			    ':o)' => 'senang',
			    ':-(' => 'sedih',
			    ':(' => 'sedih'
			);

			$sentence = strtr($sentence, $emoticons);

			$sentence = preg_replace( '/\s*\[(' . join( '|', $emoticons ) . ')\]\s*/', '[$1]', $sentence );

			return $sentence;
		}
	}	
?>
