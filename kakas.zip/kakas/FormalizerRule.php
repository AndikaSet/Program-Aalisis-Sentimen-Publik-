<?php 
	class FormalizerRule {
		private $listUnformal;
		private $listRule;
		
		private $word = "";

		function __construct($word){

			$this->word = $word;

			$this->formalizeWordList = 
			array( array("regex" => "/([a-z0-9]+)ny$/", "correction" => "$1nya"),
				   array("regex" => "/([a-z0-9]+)nk$/", "correction" => "$1ng"),
				   array("regex" => "/([a-z0-9]+)x$/", "correction" => "$1nya"),
				   array("regex" => "/([a-z0-9]+)dh$/", "correction" => "$1t"),
				   array("regex" => "/([a-z0-9]+)2$/", "correction" => "$1-$1"),
				   array("regex" => "/([a-z0-9]+)2([a-z0-9]*)$/", "correction" => "$1$1$2"),
				   array("regex" => "/oe/", "correction" => "u")
			);

			$this->convertSymbolToLetterList = 
			array( array("regex" => "@", "correction" => "a"),
				   array("regex" => "!", "correction" => "i"),
				   array("regex" => "\$", "correction" => "s")
			);

			$this->convertNumberToLetterList = 
			array( array("regex" => "12", "correction" =>	"r"),
				   array("regex" => "13", "correction" =>	"b"),
				   array("regex" => "0", "correction" =>	"o"),
				   array("regex" => "1", "correction" =>	"i"),
				   array("regex" => "2", "correction" =>	"r"),
				   array("regex" => "3", "correction" =>	"e"),
				   array("regex" => "4", "correction" =>	"a"),
				   array("regex" => "5", "correction" =>	"s"),
				   array("regex" => "6", "correction" =>	"g"),
				   array("regex" => "7", "correction" =>	"j"),
				   array("regex" => "8", "correction" =>	"b"),
				   array("regex" => "9", "correction" =>	"g")
			);
			
			$this->removeRepetitionList = 
			array( array("regex" => "/([a-z])\\1{2,}/", "correction" =>	"$1"),
				   array("regex" => "/([a-z][a-z])\\1{2,}/", "correction" =>	"$1")
			);



			$this->formalizeWord();
			$this->convertSymbolToLetter();
			$this->convertNumberToLetter();
			
			$this->removeRepetition();

		}

		function formalizeWord(){
			foreach ($this->formalizeWordList as $value) {
				extract($value);
				if (preg_match($regex, $this->word)) {
					extract($value);
					$this->word = preg_replace($regex, $correction, $this->word);
				}
			}
		}

		function convertSymbolToLetter(){
			if (preg_match("/[a-zA-Z0-9]+[\@\!\$]+[\@\!\$0-9a-zA-Z]*/", $this->word) || preg_match("/[\@\!\$]+[a-zA-Z0-9]+[\@\!\$0-9a-zA-Z]*/", $this->word)) {
				foreach ($this->convertSymbolToLetterList as $value) {
					extract($value);
					$this->word = str_replace($regex, $correction, $this->word);
				}
			}
		}

		function convertNumberToLetter(){
			if (preg_match("/[a-zA-Z]+[0-9]+[0-9a-zA-Z]*/", $this->word) || preg_match("/[0-9]+[a-zA-Z]+[0-9a-zA-Z]*/", $this->word)) {
				foreach ($this->convertNumberToLetterList as $value) {
					extract($value);
					$this->word = str_replace($regex, $correction, $this->word);
				}
			}
		}

		function removeRepetition(){
			foreach ($this->removeRepetitionList as $value) {
				extract($value);
				if (preg_match($regex, $this->word)) {
					$this->word = preg_replace($regex, $correction, $this->word);
				}
			}
		}

		function getFormalizedWord(){
			return $this->word;
		}	

	}	
?>

